#!/bin/bash

python ~alh002/atlas/plotter.py
